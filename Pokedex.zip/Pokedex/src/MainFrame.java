import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JToolBar;
import javax.swing.ScrollPaneConstants;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.JScrollPane;
import javax.swing.event.AncestorListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.event.AncestorEvent;
import javax.swing.ListSelectionModel;

public class MainFrame extends JFrame {

	private JPanel contentPane;
	private JTextField num;
	private JTextField nom;
	private JTextField ubi;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\cesar\\eclipse-workspace\\Pokedex\\9ceea7e986d7.png"));
		setTitle("Pokedex");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 281, 450);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setFont(new Font("SansSerif", Font.PLAIN, 12));
		menuBar.setBorderPainted(false);
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Archivo");
		mnNewMenu.setFont(new Font("SansSerif", Font.PLAIN, 12));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Abrir");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String filepath = "C:\\Users\\cesar\\Desktop\\Pokemon.txt";
				File file = new File(filepath);
				try {
					Scanner sc = new Scanner(file);
					DefaultTableModel model = (DefaultTableModel)table_1.getModel();
					Object[] columns = {"Numero", "Nombre", "Tipo Principal", "Tipo Secundario", "Sexo", "Ubicacion"};
					model.setColumnIdentifiers(columns);

					while (sc.hasNextLine()) {
						
						String line = sc.nextLine().trim();
						System.out.println("line : " + line);
						String[] dataRow = line.split(":");
						System.out.println("Datarow: " + dataRow);
						model.addRow(dataRow);
					}
					
					sc.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Guardar");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String filepath = "C:\\Users\\cesar\\Desktop\\Pokemon.txt";
				File file = new File(filepath);
				try {
					FileWriter fw = new FileWriter(file);
					BufferedWriter bw = new BufferedWriter(fw);
					Object[] columns = {"Numero", "Nombre", "Tipo Principal", "Tipo Secundario", "Sexo", "Ubicacion"};
					final DefaultTableModel model = new DefaultTableModel();
					model.setColumnIdentifiers(columns);
					
					for(int i=0; i< table_1.getRowCount(); i++) {
						for (int j = 0; j < table_1.getColumnCount(); j++) {
							bw.write(table_1.getValueAt(i, j).toString() + ":");
						}
						bw.newLine();
					}
					
					bw.close();
					fw.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Salir");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_2);
		
		JMenu mnNewMenu_1 = new JMenu("Ayuda");
		mnNewMenu_1.setFont(new Font("SansSerif", Font.PLAIN, 12));
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Acerca de...");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JOptionPane.showMessageDialog(null, "César Mavares \n 27.413.880 \n https://github.com/Galeceon");
				
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_3);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Número");
		lblNewLabel.setBounds(10, 11, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nombre");
		lblNewLabel_1.setBounds(92, 11, 143, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Tipo principal");
		lblNewLabel_2.setBounds(10, 67, 92, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Tipo secundario");
		lblNewLabel_3.setBounds(122, 67, 92, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Sexo");
		lblNewLabel_4.setBounds(10, 130, 92, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Ubicacion");
		lblNewLabel_5.setBounds(112, 130, 123, 14);
		contentPane.add(lblNewLabel_5);
		
		num = new JTextField();
		num.setBounds(10, 36, 46, 20);
		contentPane.add(num);
		num.setColumns(10);
		
		nom = new JTextField();
		nom.setBounds(92, 36, 143, 20);
		contentPane.add(nom);
		nom.setColumns(10);
		
		final JComboBox tip1 = new JComboBox();
		tip1.setFont(new Font("SansSerif", Font.PLAIN, 11));
		tip1.setModel(new DefaultComboBoxModel(new String[] {"Seleccionar...", "Acero", "Agua", "Bicho", "Dragón", "Eléctrico", "Fantasma", "Fuego", "Hada", "Hielo", "Lucha", "Normal", "Planta", "Psíquico", "Roca", "Siniestro", "Tierra", "Veneno", "Volador", "???"}));
		tip1.setBounds(10, 92, 92, 27);
		contentPane.add(tip1);
		
		final JComboBox sex = new JComboBox();
		sex.setFont(new Font("SansSerif", Font.PLAIN, 11));
		sex.setModel(new DefaultComboBoxModel(new String[] {"Seleccionar...", "Hombre", "Mujer", "Otro"}));
		sex.setBounds(10, 155, 92, 22);
		contentPane.add(sex);
		
		ubi = new JTextField();
		ubi.setBounds(112, 155, 123, 20);
		contentPane.add(ubi);
		ubi.setColumns(10);
		
		JButton registrar = new JButton("Registrar");
		
		registrar.setFont(new Font("SansSerif", Font.PLAIN, 11));
		registrar.setBounds(10, 188, 80, 35);
		contentPane.add(registrar);
		
		JButton limpiar = new JButton("Limpiar");
		limpiar.setFont(new Font("SansSerif", Font.PLAIN, 11));
		
		limpiar.setBounds(90, 188, 80, 35);
		contentPane.add(limpiar);
		
		JButton actualizar = new JButton("Actualizar");
		actualizar.setFont(new Font("SansSerif", Font.PLAIN, 11));
		actualizar.setBounds(170, 188, 88, 35);
		contentPane.add(actualizar);
		
		final JComboBox tip2 = new JComboBox();
		tip2.setFont(new Font("SansSerif", Font.PLAIN, 11));
		tip2.setModel(new DefaultComboBoxModel(new String[] {"Seleccionar...", "Acero", "Agua", "Bicho", "Dragón", "Eléctrico", "Fantasma", "Fuego", "Hada", "Hielo", "Lucha", "Normal", "Planta", "Psíquico", "Roca", "Siniestro", "Tierra", "Veneno", "Volador", "???"}));
		tip2.setBounds(122, 92, 92, 27);
		contentPane.add(tip2);
			
		
		
		
		Object[] columns = {"Numero", "Nombre", "Tipo Principal", "Tipo Secundario", "Sexo", "Ubicacion"};
		final DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(columns);
		final Object[] row = new Object[6];
		
		
		registrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				row [0] = num.getText();
				row [1] = nom.getText();
				row [2] = tip1.getSelectedItem();
				row [3] = tip2.getSelectedItem();
				
				if (tip2.getSelectedItem() == "Seleccionar...") {
					row [3] = "";
				}
				
				row [4] = sex.getSelectedItem();
				row [5] = ubi.getText();
				
				model.addRow(row);
				
			}
		});
		
		limpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int i = table_1.getSelectedRow();
				
				if (i >= 0) {
					model.setValueAt("", i, 0);
					model.setValueAt("", i, 1);
					model.setValueAt("", i, 2);
					model.setValueAt("", i, 3);
					model.setValueAt("", i, 4);
					model.setValueAt("", i, 5);
				}
				
			}
		});
		
		actualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int i = table_1.getSelectedRow();
				
				if (i >= 0) {
					model.setValueAt(num.getText(), i, 0);
					model.setValueAt(nom.getText(), i, 1);
					model.setValueAt(tip1.getSelectedItem(), i, 2);
					model.setValueAt(tip2.getSelectedItem(), i, 3);
					model.setValueAt(sex.getSelectedItem(), i, 4);
					model.setValueAt(ubi.getText(), i, 5);
				}
				
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(11, 245, 241, 133);
		contentPane.add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		table_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table_1.addAncestorListener(new AncestorListener() {
			public void ancestorAdded(AncestorEvent event) {
			}
			public void ancestorMoved(AncestorEvent event) {
			}
			public void ancestorRemoved(AncestorEvent event) {
			}
		});
		
		table_1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table_1.doLayout();
		
		
		
		table_1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				if (table_1.getSelectedRow() >=0) {
				int i = table_1.getSelectedRow();
				
				if (model.getValueAt(i, 0).toString() != null) {
				num.setText(model.getValueAt(i, 0).toString());
				}
				
				if (model.getValueAt(i, 1).toString() != null) {
				nom.setText(model.getValueAt(i, 1).toString());
				}
				
				tip1.setSelectedItem(model.getValueAt(i, 2));
				tip2.setSelectedItem(model.getValueAt(i, 3));
				sex.setSelectedItem(model.getValueAt(i, 4));
				
				if (model.getValueAt(i, 5).toString() != null) {
					ubi.setText(model.getValueAt(i, 5).toString());	
				}
				
				
			}}
			
			
		});
		
		table_1.setModel(model);
		
	}
	public JTable getTable_1() {
		return table_1;
	}
}
